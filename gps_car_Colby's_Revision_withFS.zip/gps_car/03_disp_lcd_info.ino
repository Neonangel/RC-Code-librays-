// ************************   DISP_LCD_INFO   ************************//

// General funcionality of LCD
void disp_lcd_info() {

  disp_time = disp_time + disp_delay;

  // Constrain LCD_screen to correct values - This used to be done in ISR, but figure this is better...
  
  // Option 1 - cap at 0 and top
  LCD_screen = constrain(LCD_screen, 0, num_LCD_screens);  // Cap screens at limits
  
  // Option 2 - wrap lcd screen around...
  // if (LCD_screen > num_LCD_screens) {
  //   LCD_screen = 0;
  // }
  // if (LCD_screen < 0) {
  //   LCD_screen = num_LCD_screens;
  // }


  if (LCD_screen_old != LCD_screen)  // if screen changes, clear old screen
  {
    lcd.clear();
    LCD_screen_old = LCD_screen;
  }

  switch (LCD_screen) {
    case 1:  // Title screen
      Title_Screen();
      break;
    case 2:  // Main Screen
      Main_Screen();
      break;
    case 3:  // Position Information
      Position_Screen();
      break;
    case 4:  // Radio Information
      Radio_Screen();
      break;
    case 5:  // Environmental Information
      Environment_Screen();
      break;
    case 6:  // Battery Information
      Battery_Screen();
      break;
    case 7: // PID information
      PID_screen();
      break;
    case 8:
      PID_gain();
      break;
    case 9:
      compass_Screen();
      break;
    default:
      lcd.setCursor(0, 1);
      lcd.print(F("**Undefined Screen**"));
      lcd.setCursor(5, 2);
      lcd.print(LCD_screen);
      break;
  }
}



// ************************   "******"_SCREEN   ************************//

// Specific Screen layouts

void Title_Screen() {  // Title screen
  //   01234567890123456789
  //0     GPS Guided Car
  //1      team_name[]
  //2       sub_name[]
  //3     course_name[]
  lcd.setCursor(0, 0);
  lcd.print(F("   GPS Guided Car "));
  lcd.setCursor(0, 1);
  lcd.print(team_name);
  lcd.setCursor(0, 2);
  lcd.print(sub_name);
  lcd.setCursor(0, 3);
  lcd.print(course_name);
}

void Main_Screen() {  // Main Screen
  //   01234567890123456789
  //0
  //1  LIDAR:####
  //2  Hdg ### GPS### Sat##
  //3  Dist ##m  ##:##:##ampm
  if (gps.location.isValid())  // valid GPS - just display location
  {
    //   01234567890123456789
    //0  ###mph Alt ### D ###
    //1  LIDAR:####
    lcd.setCursor(0, 0);
    lcd.print(gps_speed);
    lcd.print(F("mph "));
    lcd.print(F("Alt "));
    lcd.print(round(gps.altitude.feet()));
    lcd.print(F(" D "));
    lcd.print(dist_traveled);

    lcd.setCursor(10, 1);
    if (ind_gps == 0) {
      //   01234567890123456789
      //0  ###mph Alt ### D ###
      //1  LIDAR:#### Start Box  // seems to be too long for lcd
      lcd.print(F(" Start Box"));
    } else {
      //   01234567890123456789
      //0  ###mph Alt ### D ###
      //1  LIDAR:####  Tgt #/#
      lcd.print(F(" Tgt "));
      lcd.print(ind_gps + 1);
      lcd.print(F("/"));
      lcd.print(num_gps_tgts);
    }
  } else  // invalid gps - blink "Acquiring GPS..."
  {
    //   01234567890123456789
    //0  Acquiring GPS...
    //1  LIDAR:####
    blink_acquiring();
  }

  lcd.setCursor(0, 1);
  lcd.print(F("LIDAR:    "));
  lcd.setCursor(6, 1);
  lcd.print(dist_lidar);

  // clear heading and gps data, so i don't have to clear the whole line every time
  lcd.setCursor(0, 2);
  lcd.print(F("Hdg "));
  byte i = 4;
  if (compass_heading < 0) i = i - 1;
  lcd.setCursor(4, 2);
  lcd.print(F("    "));
  lcd.setCursor(i, 2);
  lcd.print(compass_heading);
  lcd.setCursor(8, 2);
  lcd.print(F("GPS "));
  i = 12;
  if (gps_heading < 0) i = i - 1;
  lcd.setCursor(12, 2);
  lcd.print(F("    "));
  lcd.setCursor(i, 2);
  lcd.print(gps_heading);
  lcd.setCursor(15, 2);
  lcd.print(F("Sat"));
  lcd.print(gps.satellites.value());

  lcd.setCursor(0, 3);
  lcd.print(F("Dist"));
  lcd.setCursor(5, 3);
  lcd.print(F("    "));
  lcd.setCursor(5, 3);
  lcd.print(constrain(dist_to_target, -5, 99));
  lcd.print(F("m"));
  lcd.setCursor(10, 3);
  lcd.print(gps_time);
  lcd.print(ampm ? F("pm") : F("am"));
}

void Position_Screen() {  // Position Information
  //   01234567890123456789
  //0  Tgt Lat: ##.######
  //1  GPS Lat: ##.######
  //2  Tgt Lng:-###.######
  //3  GPS Lng:-###.######
  lcd.setCursor(0, 0);
  lcd.print(F("Tgt "));
  lcd.print(ind_gps + 1);
  lcd.print(F("/"));
  lcd.print(num_gps_tgts);
  lcd.print(F(": "));
  lcd.print(target_lats[ind_gps], 6);
  lcd.setCursor(0, 1);
  lcd.print(F("GPS Lat: "));
  lcd.print(gps.location.lat(), 6);
  lcd.setCursor(0, 2);
  lcd.print(F("Tgt Lng:"));
  lcd.print(target_longs[ind_gps], 6);
  lcd.setCursor(0, 3);
  lcd.print(F("GPS Lng:"));
  lcd.print(gps.location.lng(), 6);
}

void Radio_Screen() {  // Radio Information
  //   01234567890123456789
  //0     Servo/ESC Info
  //1  ESC Cmd: ###
  //2  Steer Cmd: ###
  //3  Heading Error:  ###
  lcd.setCursor(0, 0);
  lcd.print(F("   Servo/ESC Info   "));
  lcd.setCursor(0, 1);
  lcd.print(F("ESC Cmd:            "));
  lcd.setCursor(10, 1);
  lcd.print(esc_command);
  lcd.setCursor(0, 2);
  lcd.print(F("Steer Cmd:          "));
  lcd.setCursor(10, 2);
  lcd.print(servo_command);
  lcd.setCursor(0, 3);
  lcd.print(F("Heading Error:      "));
  byte i = 14;
  if (heading_error < 0) i = i - 1;
  lcd.setCursor(i, 3);
  lcd.print(heading_error);
}

void Environment_Screen() {  // Environmental Information
  //   01234567890123456789
  //0  ##/##/## ##:##:##ampm
  //1  gps_age:  ###
  //2  GPS Speed:  ##mph
  //3  Heading: ###
  lcd.setCursor(0, 0);
  lcd.print(gps_date);
  lcd.print(F(" "));
  lcd.print(gps_time);
  lcd.print(ampm ? F("pm") : F("am"));
  lcd.setCursor(0, 1);
  lcd.print(F("gps_age:            "));
  lcd.setCursor(8, 1);
  if (gps.location.isValid())  lcd.print(gps.location.age());
  else lcd.print("  N/A  ");
  lcd.setCursor(0, 2);
  lcd.print(F("GPS Speed: "));
  lcd.print(gps_speed);
  lcd.print(F(" mph "));
  lcd.setCursor(0, 3);
  lcd.print(F("Heading:            "));
  lcd.setCursor(8, 3);
  lcd.print(compass_heading);
}

void Battery_Screen() {  // Battery Information
  //   01234567890123456789
  //0     Battery Status
  //1  Cell 1: ##.## V
  //2  Cell 2: ##.## V
  //3  Total : ##.## V
  calc_batt_voltage();  // measure battery voltage
  // lcd.setCursor(0, 0);
  // lcd.print(F("   Battery Status   "));
  // lcd.setCursor(0, 1);
  // lcd.print(F("Cell 1: "));
  // lcd.print(volts_cell_1);
  // lcd.print(F(" V"));
  // lcd.setCursor(0, 2);
  // lcd.print(F("Cell 2: "));
  // lcd.print(volts_cell_2);
  // lcd.print(F(" V"));
  // lcd.setCursor(0, 3);
  lcd.print(F("Total : "));
  lcd.print(volts_total);
  lcd.print(F(" V"));
}

void PID_screen() { // PID information Speed and error
  //   01234567890123456789
  //0          PID
  //1 Target speed: ***
  //2 Speed: ***
  //3 Error: speed-target
  const float rpm_to_mph = 175.36766;
  const float target_speed = 5;

  float rpm = calc_mag_rpm();
  // RPM = calc_mag_rpm();
  lcd.setCursor(0, 0);
  lcd.print(F("        PID       "));
  lcd.setCursor(0, 1);
  lcd.print(F("Target speed: "));
  lcd.print(target_speed);
  lcd.setCursor(0, 2);
  lcd.print(F("Speed(MPH): "));
  lcd.print(rpm * rpm_to_mph);
  lcd.setCursor(0, 3);
  lcd.print(F("Error: "));
  lcd.print((rpm*rpm_to_mph) - target_speed);
}

void PID_gain() { // COLBY: Variables from pid.ino have been made global
  //   01234567890123456789
  //0       PID Gain
  //1  Kp: 
  //2  Ki:
  //3  Kd: 
  lcd.setCursor(0, 0);
  lcd.print(F("    PID Gain    "));
  lcd.setCursor(0, 1);
  lcd.print(F("Kp: "));
  lcd.print(Kp);
  lcd.setCursor(0, 2);
  lcd.print(F("Ki: "));
  lcd.print(Ki);
  lcd.setCursor(0, 3);
  lcd.print(F("Kd: "));
  lcd.print(Kd);
}

void compass_Screen() {
  // 01234567890123456789
  //0      Compass Info
  //1 

  lcd.setCursor(0, 0);
  lcd.print(F("   compass info   "));
  lcd.setCursor(0, 1);
  if (FS_init && (offsetX == 0 && offsetY == 0)) {
    lcd.print(F("Press encode"));
    lcd.setCursor(0, 2);
    lcd.print(F("To calibrate"));
  } else if (!FS_init) {
    lcd.print(F("LittleFS failed"));
  } else {
      lcd.print(F("offsetX: "));
      lcd.print(offsetX);
      lcd.setCursor(0, 2);
      lcd.print(F("offsetY: "));
      lcd.print(offsetY);
      lcd.setCursor(0, 3);
      lcd.print(F("offsetZ: "));
      lcd.print(offsetZ);
  }
}

void blink_acquiring() {
  static bool acq_disp_flag = 0;
  lcd.setCursor(0, 0);
  if (acq_disp_flag) {
    lcd.print(F("                "));
    acq_disp_flag = 0;
  } else {
    lcd.print(F("Acquiring GPS..."));
    acq_disp_flag = 1;
  }
}
